import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../services/food_service.dart';

class ScannerScreen extends StatelessWidget {
  final foodService = FoodService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Scan aliment")),
      body: MobileScanner(
        onDetect: (barcode, args) async {
          final code = barcode.rawValue;
          if (code != null) {
            final food = await foodService.fetchFood(code);
            print(food['product_name']);
          }
        },
      ),
    );
  }
