import 'package:flutter/material.dart';
import '../services/ai_service.dart';

class WorkoutScreen extends StatelessWidget {
  final ai = AIService();

  @override
  Widget build(BuildContext context) {
    String result = ai.adjust(8, 0, 3);

    return Scaffold(
      appBar: AppBar(title: Text("Workout")),
      body: Center(
        child: Text("Adaptation: $result"),
      ),
    );
  }
}
