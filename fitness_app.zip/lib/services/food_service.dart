import 'dart:convert';
import 'package:http/http.dart' as http;

class FoodService {
  Future<Map<String, dynamic>> fetchFood(String barcode) async {
    final url = Uri.parse(
      'https://world.openfoodfacts.org/api/v0/product/$barcode.json'
    );

    final res = await http.get(url);
    final data = json.decode(res.body);

    return data['product'];
  }
}
