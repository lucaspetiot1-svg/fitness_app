class AIService {
  String adjust(int energy, int missed, int done) {
    if (energy <= 4) return "deload";
    if (missed >= 2) return "reduce_volume";
    if (energy >= 8 && done >= 3) return "increase_weight";
    return "maintain";
  }
}
