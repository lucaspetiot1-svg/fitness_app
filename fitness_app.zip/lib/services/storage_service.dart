import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  Future<void> saveWeight(double weight) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('weight', weight);
  }

  Future<double> getWeight() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble('weight') ?? 80;
  }
}
