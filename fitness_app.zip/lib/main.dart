import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fitness AI',
      theme: ThemeData.dark().copyWith(
        primaryColor: Color(0xFF22C55E),
        scaffoldBackgroundColor: Color(0xFF0F172A),
      ),
      home: HomeScreen(),
    );
  }
}
